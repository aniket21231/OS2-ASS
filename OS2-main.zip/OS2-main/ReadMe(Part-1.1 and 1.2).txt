

Code Logic 1.1-

- We create three functions countA,countB,countC to be executed by the 3 different threads A,B,C.
- Each function uses clock_gettime() to begin measuring time before the for loops runs from(1-2^32) and after the loop finishes.
- The time is then calculated and printed using printf and the function is returned.
- Main function is initialized with 3 pthread_t data type id's for our 3 threads and each are then created using pthread_create.
- Priority is then set for shed_param parameters using .sched_priority and which then set the priority of the threads using _setschedpriority.
- We then join each thread


Code Outcomes 1.1-

-The time taken for each Thread is displayed in seconds(s).This time follows the priority set, that is the thread with highest priority ends executing in least time.


We noticed that the scheduling policies follow their theoretical behavior i.e FIFO 

Code Logic 1.2-


- We initialised 3 pid_t for our 3 fork() calls. clock_gettime is used for measuring the time between the process beginning and ending
- First time the fork() is called, we setup an if-else loop to detect whether its the child or parent, similar nested if-else loops are used for further calls of fork().
- Inside the body of the first child, we set the priority similar to Code 1.1 using sched_param and .sched_priority and sched_setscheduler.Now, execl() call is used.
- Inside the else part,wait() is called and then clock_gettime is used again to measure the end time for the process and the time is then printed using printf.
- The second process is now forked using fork(), and again the same process is repeated as above, thereby resulting in the nesting of if- else loops.Similary,the third process is forked inside the else body of process 2 after wait() is called for proess 2. 


Code Outcomes 1.2-

- The time taken for each process is printed in seconds(s).