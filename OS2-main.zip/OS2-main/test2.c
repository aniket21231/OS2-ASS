#include <stdio.h>
#include <sys/syscall.h>
#include <unistd.h>

#define SYS_kernel_2d_memcpy 451

float* make_array(int a,int b){
    float array[a][b];
    return array;
}


int main(int argc,char **argv){

    int cntR=2;
    int cntC=2;
    
    
    float matrix_1[cntR][cntC];
    float matrix_2[cntR][cntC];
    matrix_1[0][0]=1;
    matrix_1[0][1]=2;
    matrix_1[1][0]=3;
    matrix_1[1][1]=4;
    




    printf("Initial matrix-");
    for(int temp=0;temp<2;temp++){
        for(int temp1=0;temp1<2;temp++){
            printf(" %d",matrix_1[temp][temp1]);
        }
    }
    printf("\n");

    int called= syscall(SYS_kernel_2d_memcpy,matrix_2,matrix_1,cntR,cntC);
    printf("Final Matrix after syscall-");
    
    for(int temp=0;temp<2;temp++){
        for(int temp1=0;temp1<2;temp++){
            printf(" %d",matrix_2[temp][temp1]);
        }
    }

    return 0;
    
    


}


