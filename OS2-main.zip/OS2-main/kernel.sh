#! /bin/bash 
cd /root/new_kernel/linux-5.19.9
sudo make
